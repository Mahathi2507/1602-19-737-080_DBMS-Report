package dbmsas;



import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.JTable;
import javax.swing.JScrollPane;

public class Advice {

	private JFrame frame;
	private JTextField fittxt;
	private JTextField footxt;
	private JTextField aidtxt;
	private JTable table;


	/**
	 * Create the application.
	 */
	public Advice() {
		initialize();
		this.frame.setVisible(true);
		Connect();
	}
	java.sql.Connection con;
	Statement stmt;
	ResultSet rs;
	
	 public void Connect()
	    {
		 try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
		 try 
			{
			 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","mahathi","2507");
			  stmt = con.createStatement();

			} 
			catch (SQLException connectException) 
			{
			  System.out.println(connectException.getMessage());
			  System.out.println(connectException.getSQLState());
			  System.out.println(connectException.getErrorCode());
			  System.exit(1);
			}
	    }


	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.PINK);
		frame.setBounds(100, 100, 1123, 632);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ADVICE");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel.setBounds(427, -24, 337, 111);
		frame.getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBounds(119, 75, 436, 383);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel btnNewButton_2 = new JLabel("Food Advices");
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_2.setBounds(10, 222, 155, 33);
		panel.add(btnNewButton_2);
		
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_2.setBounds(38, 222, 127, 33);
		panel.add(btnNewButton_2);
		
		JLabel btnNewButton_3 = new JLabel(" Fitness Advice");
		btnNewButton_3.setBackground(new Color(240, 240, 240));
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_3.setBounds(38, 143, 127, 33);
		panel.add(btnNewButton_3);
		
		fittxt = new JTextField();
		fittxt.setColumns(10);
		fittxt.setBounds(175, 147, 183, 33);
		panel.add(fittxt);
		
		footxt = new JTextField();
		footxt.setColumns(10);
		footxt.setBounds(175, 222, 183, 33);
		panel.add(footxt);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "Search", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_1.setBounds(148, 510, 383, 60);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel btnNewButton_2_1 = new JLabel("a_id");
		btnNewButton_2_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_2_1.setBounds(31, 11, 137, 38);
		panel_1.add(btnNewButton_2_1);
		
		aidtxt = new JTextField();
		aidtxt.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				try {
					String aid,fitness,food;
					aid=aidtxt.getText();
					fitness=fittxt.getText();
					food=aidtxt.getText();
					
					
	            	 PreparedStatement pstmt1 = con.prepareStatement("select * from advice where a_id=(?)");
	            	 pstmt1.setString(1, aid);
	            	 ResultSet rs=pstmt1.executeQuery();
	            	 while(rs.next()) {
	            		
	            	 //nametxt.setText(rs.getString(1));
	            	 fittxt.setText(rs.getString(1));
	            	 aidtxt.setText(rs.getString(2));
	            	 footxt.setText(rs.getString(3));
		            //VIDtxt.setText(rs.getString(5));
	            	 }
	            	        
				   
		   }
	            catch(Exception E)
	            { System.out.println(E);}  
			
				
			}
		});
		aidtxt.setColumns(10);
		aidtxt.setBounds(201, 18, 172, 33);
		panel_1.add(aidtxt);
		
		JButton btnNewButton_4 = new JButton("SAVE");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				{
					
					String aid,fitness,food;
					aid=aidtxt.getText();
					fitness=fittxt.getText();
					food=aidtxt.getText();
					
					try {
			            
		            	 PreparedStatement pstmt = con.prepareStatement("insert into advice values (?,?,?)");
		            	        pstmt.setString(1, aid);
		            	        pstmt.setString(2,fitness);
		            	        pstmt.setString(3,food);
		            	        int i=pstmt.executeUpdate();  
					    //txtmsg.append("\nInserted " + i + " rows successfully");
						JOptionPane.showMessageDialog(null, "\nInserted " + i + " rows successfully");
			   }
		            catch(Exception E)
		            { System.out.println(E);}  
				
				
			}
			}
		});
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_4.setBounds(730, 127, 111, 55);
		frame.getContentPane().add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("VIEW");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_5) {
					viewadvice v=new viewadvice();
				}
			}
		});
		btnNewButton_5.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_5.setBounds(743, 428, 135, 45);
		frame.getContentPane().add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("UPDATE");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_6) {
					String aid,fitness,food;
					aid=aidtxt.getText();
					fitness=fittxt.getText();
					food=footxt.getText();
				
				try {
		            
	            	 PreparedStatement pstmt = con.prepareStatement("update  advice set  fitness_advices=(?),food_advices=(?) where a_id=(?)");
	            	        pstmt.setString(3,aid);
	            	        pstmt.setString(1,fitness);
	            	        pstmt.setString(2,food);
	            	        int i=pstmt.executeUpdate();  
				    //txtmsg.append("\nInserted " + i + " rows successfully");
					JOptionPane.showMessageDialog(null, "\nupdated " + i + " rows successfully");
		   }
	            catch(Exception E)
	            { System.out.println(E);}  
		}
				
			}
		});
		btnNewButton_6.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_6.setBounds(739, 243, 122, 41);
		frame.getContentPane().add(btnNewButton_6);
		
		JButton btnNewButton_6_1 = new JButton("DELETE");
		btnNewButton_6_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_6_1) {
					String aid,fitness,food;
					aid=aidtxt.getText();
					fitness=fittxt.getText();
					food=aidtxt.getText();
					
					
					try {
			            
		            	 PreparedStatement pstmt = con.prepareStatement("delete from advice where a_id=(?)");
		            	        pstmt.setString(1, aid);
		            	        
		            	        int i=pstmt.executeUpdate();  
					    //txtmsg.append("\nInserted " + i + " rows successfully");
						JOptionPane.showMessageDialog(null, "\ndeleted " + i + " rows successfully");
			   }
		            catch(Exception E)
		            { System.out.println(E);}  
			}
				
			}
		});
		btnNewButton_6_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_6_1.setBounds(743, 342, 135, 32);
		frame.getContentPane().add(btnNewButton_6_1);
		
		table = new JTable();
		table.setBounds(724, 314, 135, -94);
		frame.getContentPane().add(table);
	}
}

